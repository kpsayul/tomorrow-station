내일 분실물 보관소 홍보 자료
https://kpsayul.github.io/tomorrow-station/

게임 소개와 플레이 후기에 이미지·영상·문구를 사용할 수 있습니다.
영상은 실제 게임 화면과 직접 합성한 짧은 음악을 담았습니다.
